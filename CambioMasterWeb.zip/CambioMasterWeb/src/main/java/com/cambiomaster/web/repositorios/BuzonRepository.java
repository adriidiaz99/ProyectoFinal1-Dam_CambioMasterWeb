package com.cambiomaster.web.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cambiomaster.web.modelo.Buzon;

public interface BuzonRepository extends JpaRepository<Buzon, Long>{

}
