package com.cambiomaster.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CambioMasterWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
